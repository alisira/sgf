﻿

/************************************** INTERFAZ *******************************************************************************/
ALTER TABLE unidadadministradora ADD COLUMN ano_presupuestario integer;
ALTER TABLE unidadadministradora ADD COLUMN cod_pagadora character varying(10);
ALTER TABLE unidadadministradora ADD CONSTRAINT unidadadministradora_id_organismo_cod_unidad_administ_ano_f_key UNIQUE (id_organismo, cod_unidad_administ, ano_presupuestario);
ALTER TABLE unidadadministradora DROP CONSTRAINT unidadadministradora_tipo;
ALTER TABLE unidadadministradora ADD CONSTRAINT unidadadministradora_tipo CHECK (tipo_unidad::text = 'O'::text OR tipo_unidad::text = 'S'::text OR tipo_unidad::text = 'A'::text OR tipo_unidad::text = '0'::text OR tipo_unidad::text = '1'::text OR tipo_unidad::text = '2'::text);
COMMENT ON COLUMN unidadadministradora.tipo_unidad IS 'El tipo de unidad puede ser:
O: Ordenadora -  denominacion anterior
S: Solicitante -  denominacion anterior
A: Ambas -  denominacion anterior
0: Unidad Administradora Desconcentrada sin delegación de firma
1: Unidad Administradora Desconcentrada con delegación de firma
2: Unidad Administradora Central';
COMMENT ON COLUMN unidadadministradora.ano_presupuestario IS 'ejercicio presupuestario';


ALTER TABLE unidadejecutora ADD CONSTRAINT unidadejecutora_id_organismo_fkey FOREIGN KEY (id_organismo)  REFERENCES organismo (id_organismo) MATCH SIMPLE ON UPDATE NO ACTION ON DELETE NO ACTION;
ALTER TABLE unidadejecutora ADD COLUMNA ano_presupuestario integer;
-- OJO: se debe crear un procedimiento que ponga 2013  a el ano presupuestario de las columnas ya existentes
ALTER TABLE unidadejecutora ADD CONSTRAINT unidadejecutora_id_organismo_cod_unidad_ejecutora_ano_fisca_key UNIQUE (id_organismo, cod_unidad_ejecutora, ano_presupuestario);

ALTER TABLE personal ADD CONSTRAINT personal_cedula_key UNIQUE (cedula);

CREATE TABLE cuentadante
(
  id_cuentadante serial NOT NULL, -- id del cuentadante
  id_organismo integer, -- id del organismo
  cedula integer, -- cedula del cuentadante
  cod_unidad_administ character varying(10), -- codigo de la unidad administradora para la cual es cuentadante
  fecha_designacion date,
  ano_presupuestario integer,
  estatus character varying(1),
  CONSTRAINT cuentadante_pkey PRIMARY KEY (id_cuentadante),
  CONSTRAINT cuentadante_cedula_fkey FOREIGN KEY (cedula)
      REFERENCES personal (cedula) MATCH SIMPLE
      ON UPDATE NO ACTION ON DELETE NO ACTION,
  CONSTRAINT cuentadante_id_organismo_fkey FOREIGN KEY (id_organismo, cod_unidad_administ, ano_presupuestario)
      REFERENCES unidadadministradora (id_organismo, cod_unidad_administ, ano_presupuestario) MATCH SIMPLE
      ON UPDATE NO ACTION ON DELETE NO ACTION
)
WITH (
  OIDS=FALSE
);
ALTER TABLE cuentadante
  OWNER TO postgres;
COMMENT ON COLUMN cuentadante.id_cuentadante IS 'id del cuentadante';
COMMENT ON COLUMN cuentadante.id_organismo IS 'id del organismo';
COMMENT ON COLUMN cuentadante.cedula IS 'cedula del cuentadante';
COMMENT ON COLUMN cuentadante.cod_unidad_administ IS 'codigo de la unidad administradora para la cual es cuentadante';

CREATE TABLE tipo_fondo
(
  id_tipo_fondo serial NOT NULL, -- identificador unico de la tabla
  denominacion character varying,
  CONSTRAINT tipo_fondo_pkey PRIMARY KEY (id_tipo_fondo)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE tipo_fondo
  OWNER TO postgres;
COMMENT ON COLUMN tipo_fondo.id_tipo_fondo IS 'identificador unico de la tabla';

INSERT INTO tipo_fondo VALUES (3, 'Avance para el personal activo');
INSERT INTO tipo_fondo VALUES (8, 'Avance para el pago del Personal Jubilado y Pensionado');
INSERT INTO tipo_fondo VALUES (9, 'Avance para el pago del Personal Becado');

CREATE TABLE cuentadante_cuenta_fondo
(
  id_cuentadante_cuenta_fondo serial NOT NULL, -- id de la tabla id_cuentadante_cuenta_fondo
  id_cuentadante integer, -- id del cuentadante
  id_tipo_fondo integer,
  cod_banco character varying(5), -- codigo de la institucion bancaria
  numero_cuenta_bancaria character varying(30), -- numero de la cuenta
  ano_presupuestario integer, -- ejercicio presupuestario
  status character varying(1),
  CONSTRAINT cuentadante_cuenta_fondo_pkey PRIMARY KEY (id_cuentadante_cuenta_fondo),
  CONSTRAINT cuentadante_cuenta_fondo_id_cuentadante_fkey FOREIGN KEY (id_cuentadante)
      REFERENCES cuentadante (id_cuentadante) MATCH SIMPLE
      ON UPDATE NO ACTION ON DELETE NO ACTION,
  CONSTRAINT cuentadante_cuenta_fondo_id_tipo_fondo_fkey FOREIGN KEY (id_tipo_fondo)
      REFERENCES tipo_fondo (id_tipo_fondo) MATCH SIMPLE
      ON UPDATE NO ACTION ON DELETE NO ACTION
)
WITH (
  OIDS=FALSE
);
ALTER TABLE cuentadante_cuenta_fondo
  OWNER TO postgres;
COMMENT ON COLUMN cuentadante_cuenta_fondo.id_cuentadante_cuenta_fondo IS 'id de la tabla id_cuentadante_cuenta_fondo';
COMMENT ON COLUMN cuentadante_cuenta_fondo.id_cuentadante IS 'id del cuentadante';
COMMENT ON COLUMN cuentadante_cuenta_fondo.cod_banco IS 'codigo de la institucion bancaria';
COMMENT ON COLUMN cuentadante_cuenta_fondo.numero_cuenta_bancaria IS 'numero de la cuenta';
COMMENT ON COLUMN cuentadante_cuenta_fondo.ano_presupuestario IS 'ejercicio presupuestario';

ALTER TABLE proyecto ALTER COLUMN enunciado TYPE character varying;
ALTER TABLE accioncentralizada ALTER COLUMN denominacion TYPE character varying;

INSERT INTO fuentefinanciamiento(id_fuente_financiamiento, cod_fuente_financiamiento, nombre) VALUES (1,'1','Ingresos Ordinarios');
INSERT INTO fuentefinanciamiento(id_fuente_financiamiento, cod_fuente_financiamiento, nombre) VALUES (2,'2','Credito Interno');
INSERT INTO fuentefinanciamiento(id_fuente_financiamiento, cod_fuente_financiamiento, nombre) VALUES (3,'3','Credito Externo');
INSERT INTO fuentefinanciamiento(id_fuente_financiamiento, cod_fuente_financiamiento, nombre) VALUES (4,'4','Venta de Activos');
INSERT INTO fuentefinanciamiento(id_fuente_financiamiento, cod_fuente_financiamiento, nombre) VALUES (5,'5','Recursos provenientes del FEM');
INSERT INTO fuentefinanciamiento(id_fuente_financiamiento, cod_fuente_financiamiento, nombre) VALUES (6,'6','Reservas del Tesoro no comprometidas');
INSERT INTO fuentefinanciamiento(id_fuente_financiamiento, cod_fuente_financiamiento, nombre) VALUES (7,'7','Otros');
INSERT INTO fuentefinanciamiento(id_fuente_financiamiento, cod_fuente_financiamiento, nombre) VALUES (8,'8','Gestion Fiscal');
INSERT INTO fuentefinanciamiento(id_fuente_financiamiento, cod_fuente_financiamiento, nombre) VALUES (9,'9','Deuda Publica');
INSERT INTO fuentefinanciamiento(id_fuente_financiamiento, cod_fuente_financiamiento, nombre) VALUES (10,'10','Proyectos por Endeudamiento');
INSERT INTO fuentefinanciamiento(id_fuente_financiamiento, cod_fuente_financiamiento, nombre) VALUES (11,'11','Compromisos y Transferencias');
INSERT INTO fuentefinanciamiento(id_fuente_financiamiento, cod_fuente_financiamiento, nombre) VALUES (12,'12','Para Pagos de Compromisos');
INSERT INTO fuentefinanciamiento(id_fuente_financiamiento, cod_fuente_financiamiento, nombre) VALUES (13,'13','PROYECTOS AGRÍCOLAS');
INSERT INTO fuentefinanciamiento(id_fuente_financiamiento, cod_fuente_financiamiento, nombre) VALUES (14,'14','GRAN MISIÓN AGRO-VENEZUELA');
INSERT INTO fuentefinanciamiento(id_fuente_financiamiento, cod_fuente_financiamiento, nombre) VALUES (15,'15','GRAN MISIÓN VIVIENDA VENEZUELA');
INSERT INTO fuentefinanciamiento(id_fuente_financiamiento, cod_fuente_financiamiento, nombre) VALUES (16,'16','GRAN MISIÓN TRABAJO VENEZUELA');
INSERT INTO fuentefinanciamiento(id_fuente_financiamiento, cod_fuente_financiamiento, nombre) VALUES (17,'17','EMERGENCIAS Y DESASTRES NATURALES');
INSERT INTO fuentefinanciamiento(id_fuente_financiamiento, cod_fuente_financiamiento, nombre) VALUES (18,'18','ENDEUDAMIENTO COMPLEMENTARIO');

ALTER TABLE cuentapresupuesto ADD COLUMN ano_presupuestario integer;

CREATE TABLE ano_presupuestario
(
  id_ano_presupuestario serial NOT NULL, -- identificador unico
  ano_presupuestario integer, -- ano presupuestario
  estatus character(1)[], -- indica se esta activo (a) o inactivo (i)
  CONSTRAINT ano_presupuestario_pkey PRIMARY KEY (id_ano_presupuestario)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE ano_presupuestario
  OWNER TO postgres;
COMMENT ON COLUMN ano_presupuestario.id_ano_presupuestario IS 'identificador unico';
COMMENT ON COLUMN ano_presupuestario.ano_presupuestario IS 'ano presupuestario';
COMMENT ON COLUMN ano_presupuestario.estatus IS 'indica se esta activo (a) o inactivo (i)';





