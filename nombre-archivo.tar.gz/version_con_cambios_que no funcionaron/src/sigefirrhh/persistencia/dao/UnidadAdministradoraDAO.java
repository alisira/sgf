package sigefirrhh.persistencia.dao;

import java.util.List;


public interface UnidadAdministradoraDAO extends GenericDAO {		
	

}
