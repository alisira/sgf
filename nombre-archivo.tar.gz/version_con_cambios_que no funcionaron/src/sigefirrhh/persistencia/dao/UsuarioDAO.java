package sigefirrhh.persistencia.dao;


public interface UsuarioDAO extends GenericDAO {		
	
	//public buscarOpcionRol 
}
