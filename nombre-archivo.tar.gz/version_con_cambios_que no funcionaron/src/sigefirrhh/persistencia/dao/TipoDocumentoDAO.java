package sigefirrhh.persistencia.dao;


public interface TipoDocumentoDAO extends GenericDAO {		
	
	//public buscarOpcionRol 
}
