package sigefirrhh.persistencia.dao;


public interface ExpedienteDAO extends GenericDAO {		
	

}
