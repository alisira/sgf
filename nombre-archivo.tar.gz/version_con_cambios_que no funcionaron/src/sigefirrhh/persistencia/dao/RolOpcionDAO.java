package sigefirrhh.persistencia.dao;


public interface RolOpcionDAO extends GenericDAO {		
	
}
