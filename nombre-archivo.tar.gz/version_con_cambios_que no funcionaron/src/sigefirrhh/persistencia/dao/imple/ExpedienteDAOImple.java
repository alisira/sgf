package sigefirrhh.persistencia.dao.imple;

import sigefirrhh.persistencia.dao.ExpedienteDAO;

public class ExpedienteDAOImple extends GenericDAOImplHibernate implements ExpedienteDAO {
	
	public ExpedienteDAOImple(){
		super();
	}

}
