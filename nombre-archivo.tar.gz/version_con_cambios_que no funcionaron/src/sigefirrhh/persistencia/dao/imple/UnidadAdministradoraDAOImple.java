package sigefirrhh.persistencia.dao.imple;

import sigefirrhh.persistencia.dao.UnidadAdministradoraDAO;


public class UnidadAdministradoraDAOImple extends GenericDAOImplHibernate implements UnidadAdministradoraDAO {
   
    public UnidadAdministradoraDAOImple() {
        super();
    }
    
}