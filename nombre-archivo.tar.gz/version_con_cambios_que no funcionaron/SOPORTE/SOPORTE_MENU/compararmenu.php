
<html>
<head>
	<title>403 Forbidden</title>
</head>
<body>


<ul>
	<li>Opcion _1
		<ul>
			<li>
				Opcion 1_1
			</li>
			<li>
				Opcion 1_2
				<ul>
					<li>Opcion 12_1</li>
					<li>Opcion 12_2</li>
				</ul>
			</li>
			<li>
				Opcion 1_3
			</li>
		</ul>
	</li>


	<li>Opcion _2
		<ul>
			<li>
				Opcion 2_1
			</li>
			<li>
				Opcion 2_2
				<ul>
					<li>Opcion 22_1</li>
				</ul>
			</li>
		</ul>
	</li>
	<li>Opcion _3
	</li>
	
</ul>








<div id="contenedor" style=" opacity: 0.7; height: 500px;">
    <ul class="mnmenu" id="idmenu2">
        <li class="level-0 middle last">
                <span class="level-1">
                    Control de Acceso
                </span>
            
	    	<ul style="z-index: 4; left: 0px; right: auto; top: 25px; bottom: auto; width: 210px; display: block;" class="level-1">
		    <li class="level-0 middle last">
		        <a class="level-1" href="">
		            <span class="level-1">
		                Acceso de Visitantes
		            </span>
		        </a>
		    </li>
		    <li class="level-0 middle last">
		        <a class="level-1" href="http://localhost/controlacceso/control_acceso_con">
		            <span class="level-1">
		                Acceso de Empleados
		            </span>
		        </a>
		    </li>


        	</ul>

</li>
        <li class="level-0 middle last"><a class="level-1" href=""> <span class="level-1">Reportes</span></a><ul style="z-index: 4; left: 0px; right: auto; top: 25px; bottom: auto; width: 210px; display: block;" class="level-1"><li class="level-0 middle last"><a class="level-1" href=""> <span class="level-1">Reporte de Acceso Empleados</span></a></li><li class="level-0 middle last"><a class="level-1" href=""> <span class="level-1">Reporte de Acceso Visitantes</span></a></ul><li class="level-0 middle last"><a class="level-1" href=""> <span class="level-1">RRHH</span></a><ul style="z-index: 4; left: 0px; right: auto; top: 25px; bottom: auto; width: 210px; display: block;" class="level-1"><li class="level-0 middle last"><a class="level-1" href=""> <span class="level-1">Empleados</span></a></ul><li class="level-0 middle last"><a class="level-1" href=""> <span class="level-1">Administracion</span></a><ul style="z-index: 4; left: 0px; right: auto; top: 25px; bottom: auto; width: 210px; display: block;" class="level-1"><li class="level-0 middle last"><a class="level-1" href=""> <span class="level-1">Procesos</span></a></li><li class="level-0 middle last"><a class="level-1" href=""> <span class="level-1">Perfil</span></a></li><li class="level-0 middle last"><a class="level-1" href=""> <span class="level-1">Proceso por Perfil</span></a></li><li class="level-0 middle last"><a class="level-1" href=""> <span class="level-1">Usuario</span></a></li></ul></li>
        <li class="level-0 middle last">
            <a href="/controlacceso/index.php/logoff_con/" class="level-1"> 
                <span class="level-1">
                    Salir
                </span>
            </a>
        </li>
    </ul>
</div>


<ul>
<li>Esto es un tipo de punto.
	<ul>
		<li>Esto es un tipo de punto.

		</li>
		<li>Este es otro.</li>
		<li>Y este es otro diferente.
			<ul>
				<li>Esto es un tipo de punto.

				</li>
				<li>Este es otro.</li>
				<li>Y este es otro diferente.</li>
			</ul>



		</li>
	</ul>

</li>
<li>Este es otro.</li>
<li>Y este es otro diferente.</li>
</ul>


<br>
<ul><li>Opcion _1<ul><li>Opcion 1_1</li><li>Opcion 1_2<ul><li>Opcion 12_1</li><li>Opcion 12_2</li></ul></li><li>Opcion 1_3</li></ul></li><li>Opcion _2<ul><li>Opcion 2_1</li><li>Opcion 2_2<ul><li>Opcion 22_1</li></ul></li></ul></li><li>Opcion _3</li></ul>
</body>
</html>

