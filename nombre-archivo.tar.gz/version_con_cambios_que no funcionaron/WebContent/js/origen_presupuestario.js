$(function() {
    $('#fechaGaceCredi').datetimepicker({
    	 language: 'es'
    });
    $('#fechaGaceRecti').datetimepicker({
   	 language: 'es'
   });
  });